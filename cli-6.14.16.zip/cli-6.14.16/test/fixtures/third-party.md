"scoped-underscore-1.3.1.tgz" includes content from the Underscore package,
including code adapted from ES 5.1 section 15.12.3, abstract operation
`JO`, used under the following license:

Copyright (c) Ecma International 2010 

DISCLAIMER This document may be copied and furnished to others, and
derivative works that comment on or otherwise explain it or assist in its
implementation may be prepared, copied, published, and distributed, in
whole or in part, without restriction of any kind, provided that the above
copyright notice and this section are included on all such copies and
derivative works. However, this document itself may not be modified in any
way, including by removing the copyright notice or references to Ecma
International, except as needed for the purpose of developing any document
or deliverable produced by Ecma International.

The limited permissions are granted through the standardization phase and
will not be revoked by Ecma International or its successors or assigns
during this time.

This document and the information contained herein is provided on an "AS
IS" basis and ECMA INTERNATIONAL DISCLAIMS ALL WARRANTIES, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO ANY WARRANTY THAT THE USE OF THE
INFORMATION HEREIN WILL NOT INFRINGE ANY OWNERSHIP RIGHTS OR ANY IMPLIED
WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.
